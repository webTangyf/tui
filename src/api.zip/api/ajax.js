import axios from 'axios'
import { encrypt } from './params/sign.js'
import ajaxCahche from './cacheAjax.js'
import cacheConFig from './config.js'
const qs = require('qs');
let instance = axios.create({
  baseURL: '/huatai',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    'Accept': 'application/json',
    'X-Requested-With': 'XMLHttpRequest'
  },
  transformRequest: [function (data) {
      return qs.stringify(data)
  }],
})
instance.interceptors.request.use(config => {
  const method = config.method.toLowerCase()
  if (method === 'post' || method === 'put') {
    config.data = encrypt.getParams(config.data || {})
  } else if (method === 'get'|| method == 'delete') {
    config.params = encrypt.getParams(config.params || {})
  }
  return config
}, (error) => {
  return Promise.reject(error)
})

instance.interceptors.response.use((res) => {
  if (res.data.code === '0000') {
    return res
  } else {
    return Promise.reject(res.data.msg)
  }
}, (error) => {
  alert(error)
  const status = error.response ? error.response.status : 600
  switch (status) {
    case 404:
      alert('接口不存在')
      break
    case 500:
      alert('服务器错误')
      break
    default:
      alert('未知错误')
  }
  return Promise.reject(error)
})

instance = ajaxCahche(instance, {
  activeDate: 50 * 1000 * 60,
  maxCacheSize: 15,
  ajaxMap: cacheConFig,
  handleJudge: function (data, cb) {
    if(data.code === '0000') {
      cb&&cb()
    }
  }
})

export default instance
