export default {
  bannerList: { //  获取广告页面， 开屏页
    url: '/bannerimg/findlist',
    cache: true,                         // 是否做缓存处理
    publish: ['findlist']                          // 如果该接口更新了的话 需要去更新的接口
  }, 
  fundlist: { 
    url: '/query/fundlist',
    cache: false,                        
    publish: ['bannerList']                         
  }, 
  findlist: { 
    url: '/question/findlist',
    cache: true,                        
    publish: []                         
  }
}